<?php
echo $nilai_agama;
?>